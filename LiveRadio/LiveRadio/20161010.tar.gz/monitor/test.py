# coding:utf-8

import time
import threading

tt = [1,3,4,5,2,7,8,3,2]
dd = tt*3
print dd